# v0.4.0-alpha.40

- Moved the authoritative Ranked map catalog to `sheet2` by default while preserving Corum Integration's independent `sheet1` routing; `RANKED_MAPS_SHEET_NAME` can override only the Ranked tab.
- Updated the fixed Ranked rules to `corum-ranked-v0.4`: five-minute rounds, three Clears, and the existing ten-second FINAL/LAST attempt-start windows.
- Expanded the client HUD and result/history UI to three Clear checks, and aligned client re-entry blocking, server spectator authorization, Debug Bot scenarios, and regression fixtures with the new Clear target.
- Preserved in-progress legacy `corum-ranked-v0.3` match snapshots as two-Clear matches during a rolling server deployment; newly created matches validate at exactly three Clears.
- Fixed blank/default Geometry Dash LevelInfo metadata by normalizing the downloaded Ranked level as a Search Result and synchronizing the server-provided title/creator before the vanilla layer renders.
- Fixed repeated Android Ranked resource downloads by making the mod's persistent save directory the authoritative BGM cache. Geometry Dash's custom-song path is now a best-effort compatibility mirror and can change without reopening the resource gate.
- Updated the exact client/server version gate and workspace metadata to `v0.4.0-alpha.40`. No database migration is required; update/redeploy Apps Script and rerun `setupCorumRankedConfig()` after creating `sheet2`.

# v0.4.0-alpha.39

- Normalized Attempt End progress to the server's three-decimal wire contract, preventing raw Geometry Dash percentages from returning HTTP 400 and permanently blocking the FIFO before later Clears.
- Treats deterministic HTTP 4xx Attempt Start/End failures as terminal for that event while continuing to retry network, 5xx, timeout, Too Early, and rate-limit failures.
- Removed the initialization-only phantom `Start -> End 0 -> Start` sequence by journaling the first attempt after Geometry Dash's short scene-setup reset window; a genuine early death/Clear still self-recovers and is recorded.
- Fixed the three-minute boundary HUD so it changes directly from the normal clock to visible `FINAL ATTEMPT 10.0 ... 0.0`, even before the next authoritative poll arrives.
- Enforced the 10-second new-attempt deadline locally for stale `ROUND_PLAYING` snapshots while preserving every attempt that started in time until its natural death or Clear.
- Fixed Ranked completion-layer exits: closed Replay is redirected through the vanilla Menu path, and two-Clear/result transitions leave the completion overlay without orphaning its controls.
- Replaced the misleading `OPENING LEVEL / WAITING MAP` presentation during a pending second-Clear acknowledgement with `CLEAR RECORDED / SYNCING RESULT`.
- Added server-side defensive Attempt End normalization plus regression tests for second Clears after 3:00 and LAST ATTEMPT windows crossing the original 3:00 deadline.
- Fixed the `Validate Corum Ranked` Actions fixture so every locally generated Ranked Pool map includes the now-required alternate map code; the workflow no longer fails independently of the operator's real Spreadsheet values.
- Preserved the existing Geometry Dash LevelInfo Play-button activation path and Match music handoff; gameplay is not constructed directly by Ranked.
- Updated the exact client/server version gate and workspace metadata to `v0.4.0-alpha.39`. No database migration or Apps Script change is required.

# v0.4.0-alpha.38

- Fixed the reproducible iOS `CCTouchDispatcher::handleTouchesEnd` crash by stopping 200 ms full-menu rebuilds and explicitly clearing `CCMenu::m_pSelectedItem` before any structural UI cleanup. Countdown, download, queue, and spectator values now update in place.
- Added explicit Ranked scene input cleanup: the refresh schedule, keypad delegate, and menu touch dispatcher are disabled before the Ranked scene exits.
- Added poll-request generations and cancellation. A response from a dismissed/previous match can no longer restore old match state after **QUEUE AGAIN**, Close, Leave Queue, or a new session.
- Replaced the LevelInfo `onPlay()` watchdog/retry loop with direct construction of `PlayLayer` from Geometry Dash's canonical saved level payload. A non-null `PlayLayer::scene()` is now the launch success signal, removing the observed endless `SENDING READY...` / repeated arm loop.
- Updated the exact client/server version gate and workspace metadata to `v0.4.0-alpha.38`.
- Scoring, MMR/RP, map pool, ban rules, attempt limits, and server database schema are unchanged.

# v0.4.0-alpha.33

- Added durable PostgreSQL Start Leases for every standard-round visual attempt so a delayed FIFO Start/End cannot be lost when polling reaches a Round result first; leases survive Render process restarts.
- The client no longer discards completed attempt transport when an authoritative result poll races ahead, and newest lease requests preempt older slow lease HTTP waits.
- Added idempotent round Start/End reconciliation for lost HTTP acknowledgements.
- Fixed Death Match visual budgeting so an attempt is consumed only when the new visual Start journal is actually created; the third visual attempt is no longer pre-spent while the server still shows 2/3.
- Death Match popup usage now includes the viewer's locally-created visual attempt while its server ACK is pending.
- Keeps the next Round / MATCH POINT / Death Match map card visible for the first 5 seconds before opening the normal LevelInfo/resource gate; the existing total 10-second prepare period and authoritative timer semantics remain unchanged.
- Replaced Ranked BGM playback through `FMODAudioEngine::playMusic()` with a Ranked-owned direct FMOD streaming Sound/Channel.
- Added explicit `pauseSound()` handling plus iPadOS/iOS `resumeSound()` recovery, FMOD master-output normalization, playback-position watchdog/retry, and automatic loop recovery.
- Ranked BGM volume is Geometry Dash's current Music Volume multiplied by 0.80.
- Ranked resource downloads prefer Geometry Dash's canonical song path and migrate valid old private-cache songs when possible.
- Added PostgreSQL migration `0002_attempt_start_leases.sql`. Apps Script, scoring/MMR, map pool, ban rules, and FINAL/LAST 10-second start-window rules are unchanged.

# v0.4.0-alpha.32

- Fixed Ranked BGM remaining completely silent even after all configured songs downloaded successfully.
- Replaced the old `fadeOutMusic() -> playMusic()` handoff with a fade followed by `stopAllMusic(true)` before installing the Ranked track, preventing the previous Geometry Dash menu channel from remaining registered in a silent/fading state.
- Explicitly unpauses the main music channel group and restores Geometry Dash's current music volume before Ranked playback.
- Added a playback watchdog: the client verifies that FMOD actually created a live main-music channel and retries the track up to two times instead of permanently assuming a failed `playMusic()` call succeeded.
- Delayed configured start-position seeking until the new music channel is confirmed active.
- Ranked private-cache files now require a valid MP3/Ogg/FLAC/WAV/MP4 audio signature; HTML/error bodies can no longer be accepted merely because they are larger than 1 KB.
- Leaving Ranked now hard-stops the Ranked music slot before asking Geometry Dash to recreate its normal menu music.
- No server, scoring, MMR, map-pool, attempt, FINAL/LAST ATTEMPT, or Debug Bot behavior was changed.

# v0.4.0-alpha.31

- Fixed the two-Clear LAST ATTEMPT transition so the triggering player enters the opponent spectator screen immediately instead of seeing a misleading second `STARTS IN 10` prepare screen.
- The spectator screen now distinguishes an opponent that has not started yet (`WAITING TO START`) from a live attempt and shows the remaining LAST ATTEMPT start window.
- Fixed Debug Bot Match deadlock when a Bot attempt survives past the LAST ATTEMPT start deadline and the round enters `ROUND_SETTLING`.
- Debug Bot simulation now continues progress/end ticks for an already accepted Bot attempt during `ROUND_SETTLING`, while still forbidding new attempts after the deadline.
- Added recovery for an authoritative in-progress Bot attempt after a dev/Render server restart during `ROUND_SETTLING`.
- Added a regression test that verifies the Bot final attempt is closed and the match leaves `ROUND_SETTLING`.
- No scoring, MMR, map-pool, ban, FINAL/LAST ATTEMPT deadline, or normal PvP attempt semantics were changed.

# v0.4.0-alpha.30

- Fixed Ranked lobby/resource BGM downloads that could fail when Geometry Dash had not already loaded the configured Song ID metadata.
- Removed direct `MusicDownloadManager::downloadSong()` use from Ranked resource acquisition.
- Ranked now fetches Geometry Dash song metadata and downloads configured BGM sequentially with Geode `WebRequest` into a private Ranked audio cache.
- Existing Geometry Dash-downloaded songs remain preferred and are reused without duplicate downloads.
- Preserved `RANKED RESOURCES`, download progress, `RETRY FAILED`, `CONTINUE`, audio fades, and all existing gameplay/scoring/MMR behavior.

# v0.4.0-alpha.29

- Added Config-driven Ranked audio using Geometry Dash custom Song IDs with per-track start positions in seconds.
- Added `RANKED RESOURCES` first-entry/update gate. Missing configured resources are skipped if already present and can be fetched in one action with `DOWNLOAD ALL`.
- Added sequential resource download progress, 60-second per-resource timeout, `RETRY FAILED`, and `CONTINUE` after all resources are ready.
- Added Ranked BGM state mapping for Main/Queue, Match/Ban/Prepare/Spectator, and Win/Lose results with fallback to already configured tracks.
- Added configurable music fade-in/fade-out and UI fade-out/fade-in transitions. Same-track phase changes do not restart playback.
- Ranked audio fades out before vanilla LevelInfo/gameplay and Geometry Dash menu music is restored when leaving Ranked.
- Added server pass-through and validation for the client presentation config without changing gameplay rules or scoring.

# v0.4.0-alpha.28

- Removed the 30-second FINAL/LAST ATTEMPT start-intent expiry. A valid pre-deadline intent now holds the round while the player remains connected; a 15-minute hard TTL exists only as a deadlock guard.
- Preserved the bounded 5-second late packet reconciliation window; the actual 10-second gameplay start deadline is unchanged.
- Removed absolute `orphanAttemptSeconds` force-ending for active Round/Death Match attempts. Connected attempts now end only by natural death/Clear; disconnect policy handles abandoned clients.
- Repeated same-percent progress telemetry now refreshes the active-attempt lease heartbeat.
- Added a client safeguard that refuses to `onQuit()` a still-alive visual attempt merely because polling published an early result state.
- Prevented vanilla reset from creating a new visual attempt whenever the authoritative state no longer permits a new start.
- Replaced the full-screen `SYNCING RESULT` dead-end with immediate authoritative result rendering and terminal transport cleanup for already-finalized events.
- Serialized FINAL/LAST start-intent delivery with retry so multiple quick final-window starts cannot silently overwrite an in-flight intent request.
- Hardened the PostgreSQL pool against Neon idle connection drops so an emitted pool error no longer terminates the Render process; rollback failure can no longer mask the original DB error.

# v0.4.0-alpha.27

- Fixed FINAL/LAST ATTEMPT semantics so an attempt that visually starts before the 10-second start deadline is never force-ended when the window expires.
- Added an out-of-band start-intent signal for FINAL/LAST ATTEMPT. It does not create an attempt or extend gameplay time; it only prevents the authoritative server from finalizing while the serialized Start event is still catching up.
- Added server-side intent-aware recovery for a valid pre-deadline Start that reaches the authoritative FIFO after the deadline, then transitions the round to ROUND_SETTLING while the active attempt continues naturally.
- Added a Ranked spectator waiting screen after the local final attempt ends first, showing the opponent name and live progress until their active attempt finishes.
- Preserved the 10-second start deadline: new attempts after the deadline remain forbidden.
- Added rules/runtime regression coverage for late transport of a pre-deadline visual start.

# v0.4.0-alpha.27
- Prevented stale `/attempt/progress` responses from overwriting newer Attempt End/Clear snapshots; progress callbacks are now applied only while the same attempt is still active and has no queued End.
- Snapshotted the first visual Attempt start at LevelInfo -> PlayLayer arm time, so a legal scene transition can still journal its Start if server polling changes phase before PlayLayer finishes constructing. New scene entry is now forbidden in `ROUND_SETTLING`.
- Scoped optimistic Score/Clear presentation to the exact Round or Death Match sequence so pending events from the previous round cannot leak into the next round HUD.
- Blocked vanilla `resetLevel()` while the server is in `ROUND_SETTLING`, preventing a fake extra visual attempt after Final/LAST Attempt has already closed.
- Added a PLAYING-state LevelInfo recovery path so skipped `DEATHMATCH_PREPARE` / fast server transitions cannot leave the client permanently stuck on Loading Map.
- Ranked LevelInfo preparation now labels the actual phase: `ROUND 1`, `ROUND 2 - MATCH POINT`, `ROUND 3 - TIEBREAKER`, or `DEATH MATCH` instead of the generic `RANKED MATCH` text.
- Extended integration regression coverage to verify Round 2 starts with authoritative score/display score/clears all reset to zero.
- Preserves alpha.25 transport reconciliation, server-authoritative scoring, 70%+ x1.5 scoring, Clear=200, and all existing anti-cheat/rules behavior.

# v0.4.0-alpha.25
- Replaced the stretched `square02_001.png` Scale9 panel system with deterministic `CCLayerColor` panels. This removes the opaque black rectangles that could cover cards, LevelInfo UI, the vanilla progress bar, and gameplay percentage.
- Reduced the gameplay HUD footprint and moved the Ranked timer/state lower so Geometry Dash's native progress bar and percentage remain unobstructed.
- Shrunk the LevelInfo Ranked gate into a compact countdown/status strip while keeping the vanilla song acquisition controls as the only enabled inputs during preparation.
- Added client-observed `clientStartedAt` / `clientEndedAt` timestamps to Attempt transport using the synchronized server clock.
- Added a bounded 2-second server transport-reconciliation grace: gameplay deadlines are unchanged, but a Start packet observed before the deadline can still be accepted if network delivery lands immediately after it.
- Attempt Start/End FIFO entries are no longer erased when polling reaches `ROUND_RESULT`, `DEATHMATCH_RESULT`, `MATCH_RESULT`, or spectator state before their ACKs.
- PlayLayer now journals an outstanding visual attempt before automatic scene exit, closing another path where local progress/Clear could disappear before authoritative submission.
- Match dismissal / Queue Again waits for pending attempt transport instead of throwing away unsynchronized result events.
- Added server timing regression tests for bounded client timestamps and the transport-settling window.
